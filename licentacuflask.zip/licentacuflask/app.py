import json
from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'secret_key'  # Cheia secretă pentru sesiuni

# Numele fișierului JSON pentru stocarea utilizatorilor
USERS_FILE = 'users.json'

def load_users():
    try:
        with open(USERS_FILE, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_users(users):
    with open(USERS_FILE, 'w') as file:
        json.dump(users, file)

# Lista pentru stocarea utilizatorilor
users = load_users()

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = next((u for u in users if u['username'] == username and u['password'] == password), None)
        if user:
            # Autentificare reușită, setează variabila de sesiune și redirecționează către pagina de bord
            session['username'] = user['username']
            return redirect(url_for('dashboard'))
        # Autentificare eșuată, afișează mesaj de eroare
        return render_template('login.html', error='Autentificare eșuată. Verificați numele de utilizator și parola.')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if any(u['username'] == username for u in users):
            # Utilizatorul există deja, afișează mesaj de eroare
            return render_template('signup.html', error='Numele de utilizator există deja. Alegeți un altul.')
        users.append({'username': username, 'password': password})
        save_users(users)
        # Înregistrare reușită, afișează mesaj de succes și redirecționează către pagina de autentificare
        return render_template('signup.html', success=True)
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    # Șterge variabila de sesiune și redirecționează către pagina de autentificare
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
