import difflib
import ast
import subprocess
import time
from jinja2 import Template

# ...
import difflib #diferente program
import ast
import subprocess
import time

# Citim cele doua programe
with open("C:/Users/roman/PycharmProjects/prim/main.py") as file1:
    program1 = file1.read()

with open("C:/Users/roman/PycharmProjects/Eratostene/main.py") as file2:
    program2 = file2.read()


import ast
import difflib

def extract_semantic_info(ast_node):
    # Extrage informațiile semantice relevante dintr-un arbore sintactic abstract (AST)
    # Ignoră spațiile libere și comentariile în funcții
    semantic_info = {
        'functions': [],
        'variables': []
    }

    for node in ast.walk(ast_node):
        if isinstance(node, ast.FunctionDef):
            semantic_info['functions'].append(node.name)
        elif isinstance(node, ast.Name):
            semantic_info['variables'].append(node.id)

    return semantic_info

def compare_code_similarity(code1, code2):
    # Analizează arborele sintactic abstract (AST) pentru primul cod
    ast1 = ast.parse(code1)

    # Analizează arborele sintactic abstract (AST) pentru al doilea cod
    ast2 = ast.parse(code2)

    # Extrage informațiile semantice relevante din primul cod
    semantic_info1 = extract_semantic_info(ast1)

    # Extrage informațiile semantice relevante din al doilea cod
    semantic_info2 = extract_semantic_info(ast2)

    # Compară semantica și calculează scorul de similaritate
    similarity_score = compute_similarity_score(semantic_info1, semantic_info2)

    return similarity_score

def compute_similarity_score(semantic_info1, semantic_info2):
    # Calculează scorul de similaritate pe baza informațiilor semantice
    # Ignoră spațiile libere și comentariile în funcții
    function_similarity = difflib.SequenceMatcher(None, semantic_info1['functions'], semantic_info2['functions']).ratio()
    variable_similarity = difflib.SequenceMatcher(None, semantic_info1['variables'], semantic_info2['variables']).ratio()

    # Atribuie ponderi diferite în funcție de importanța aspectelor semantice
    function_weight = 0.7
    variable_weight = 0.3

    # Calculează scorul de similaritate total
    similarity_score = function_weight * function_similarity + variable_weight * variable_similarity

    return similarity_score

# Citirea căilor fișierelor dintr-un document txt
file_path = input("Introduceți calea către documentul txt: ")
with open(file_path, "r") as file:
    program_paths = file.read().splitlines()

# Citirea și stocarea conținutului fiecărui fișier
programs = []
for path in program_paths:
    with open(path, "r") as file:
        program = file.read()
        programs.append(program)

# Numărul de fișiere pentru comparare
n = len(programs)

# Calcularea procentului de similaritate între toate perechile de fișiere
similarities = []
differences = []
for i in range(n):
    for j in range(i + 1, n):
        similarity_ratio = compare_code_similarity(programs[i], programs[j]) * 100
        similarities.append((i, j, similarity_ratio))

        # Calcularea și afișarea diferențelor
        differ = difflib.Differ()
        diff = differ.compare(programs[i].splitlines(), programs[j].splitlines())
        diff_output = []
        for line in diff:
            prefix = line[:2]
            text = line[2:].strip()
            if prefix == "  ":
                diff_output.append(f"  {text}")
            elif prefix == "- ":
                diff_output.append(f"- {text}")
            elif prefix == "+ ":
                diff_output.append(f"+ {text}")
        differences.append(diff_output)

# Afișarea procentelor de similaritate și diferențelor
for i, j, similarity in similarities:
    print(f"Procent de similaritate între {program_paths[i]} și {program_paths[j]}: {similarity:.2f}%")
    diff_output = differences[i * (n - i - 1) + j - 1]
    if diff_output:
        print("Diferențe:")
        print("\n".join(diff_output))
    print()

    if similarity == 100.0:
        print(f"Programul {program_paths[i]} este identic cu {program_paths[j]}.")
    elif similarity >= 90.0:
        print(f"Programul {program_paths[i]} este foarte similar cu {program_paths[j]}.")
    elif similarity >= 75.0:
        print(f"Programul {program_paths[i]} este similar cu {program_paths[j]}.")
    else:
        print(f"Programul {program_paths[i]} este diferit de {program_paths[j]}.")
    print()

# Calcularea și afișarea timpilor de execuție
execution_times = []
for path in program_paths:
    start_time = time.time()
    subprocess.run(["python", path], check=True)
    execution_time = time.time() - start_time
    execution_times.append(execution_time)

# Calcularea și afișarea timpilor de execuție în ordine crescătoare
sorted_programs = sorted(zip(program_paths, execution_times), key=lambda x: x[1])
for i, (path, execution_time) in enumerate(sorted_programs):
    print(f"Timpul de execuție pentru programul {i + 1} ({path}): {execution_time:.6f} secunde")

# Compararea timpilor de execuție
sorted_programs = sorted(zip(program_paths, execution_times), key=lambda x: x[1])

best_time = sorted_programs[0][1]
worst_time = sorted_programs[-1][1]

best_programs = [path for path, execution_time in sorted_programs if execution_time == best_time]
worst_programs = [path for path, execution_time in sorted_programs if execution_time == worst_time]

print("\nCompararea timpilor de execuție:")
print(f"Cel mai bun timp de execuție: {best_time:.6f} secunde")
print("Program(e) cu cel mai bun timp:")
for program, execution_time in sorted_programs:
    if execution_time == best_time:
        print(f"Cale: {program}, Timp: {execution_time:.6f} secunde")
print()
print(f"Cel mai prost timp de execuție: {worst_time:.6f} secunde")
print("Program(e) cu cel mai prost timp:")
for program, execution_time in sorted_programs:
    if execution_time == worst_time:
        print(f"Cale: {program}, Timp: {execution_time:.6f} secunde")

print("\nProgram(e) în ordinea timpilor de execuție:")
for i, (path, execution_time) in enumerate(sorted_programs):
    print(f"{i + 1}. Cale: {path}, Timp: {execution_time:.6f} secunde")




import ast
import difflib

def compara_lista_programe(program_referinta, fisier_lista_program):
    with open(program_referinta, 'r') as file:
        cod_referinta = file.read()

    with open(fisier_lista_program, 'r') as file:
        lista_programe = file.read().splitlines()

    for program in lista_programe:
        with open(program, 'r') as file:
            cod_sursa = file.read()

        # Transformă codul sursă în arbore sintactic abstract (AST)
        arbore_referinta = ast.parse(cod_referinta)
        arbore_program = ast.parse(cod_sursa)

        # Compară arborele sintactic pentru a identifica diferențele sau asemănările
        if ast.dump(arbore_referinta) == ast.dump(arbore_program):
            print(f"Programul {program} face același lucru ca și programul de referință.")
        else:
            # Calculează procentul de similaritate între cele două programe
            similarity_ratio = difflib.SequenceMatcher(None, ast.dump(arbore_referinta), ast.dump(arbore_program)).ratio() * 100

            if similarity_ratio >= 90.0:
                print(f"Programul {program} este foarte similar cu programul de referință, dar poate necesita o evaluare manuală.")
            else:
                print(f"Programul {program} este diferit de programul de referință și necesită o evaluare manuală.")

# Exemplu de utilizare
program_referinta = program_referinta = input("Introduceți calea către programul de referință: ")
fisier_lista_program = file_path

compara_lista_programe(program_referinta, fisier_lista_program)


import ast

def analyze_code(code):
    MAX_LINES_PER_FUNCTION = 30
    MAX_ELEMENTS_PER_FUNCTION = 10
    MAX_COMPLEXITY_PER_FUNCTION = 10

    try:
        module = ast.parse(code)
    except SyntaxError as e:
        print(f"Syntax error: {e}")
        return

    errors = []

    # Verificare dacă există linii cu lungimea prea mare
    for i, line in enumerate(code.split('\n')):
        if len(line) > 79:
            errors.append(f"Lungimea liniei {i + 1} depășește 79 de caractere")

    # Verificare dacă există linii goale sau cu spații inutile
    lines = code.split('\n')
    for i, line in enumerate(lines):
        if not line.strip():
            errors.append(f"Linia {i + 1} este goală")
        elif line.endswith(' ') or line.endswith('\t'):
            errors.append(f"Linia {i + 1} conține spații sau tab-uri inutile la final")

    # Verificare dacă există funcții prea mari sau complexe
    functions = [node for node in ast.walk(module) if isinstance(node, ast.FunctionDef)]
    for function in functions:
        num_lines = function.lineno - function.body[0].lineno
        num_elements = len(function.body)
        num_complexity = len(
            [node for node in ast.walk(function) if isinstance(node, (ast.If, ast.For, ast.While, ast.With))])

        if num_lines > MAX_LINES_PER_FUNCTION:
            errors.append(
                f"Funcția {function.name} depășește limita de {MAX_LINES_PER_FUNCTION} linii (are {num_lines} linii)")

        if num_elements > MAX_ELEMENTS_PER_FUNCTION:
            errors.append(
                f"Funcția {function.name} depășește limita de {MAX_ELEMENTS_PER_FUNCTION} elemente (are {num_elements} elemente)")

        if num_complexity > MAX_COMPLEXITY_PER_FUNCTION:
            errors.append(
                f"Funcția {function.name} depășește limita de {MAX_COMPLEXITY_PER_FUNCTION} niveluri de complexitate (are {num_complexity} niveluri)")

    if errors:
        print("Probleme găsite:")
        for error in errors:
            print(error)
    else:
        print("Codul este corect formatat!")


# Citirea căilor fișierelor dintr-un document txt

with open(file_path, "r") as file:
    program_paths = file.read().splitlines()




# Analizarea codului pentru fiecare fișier
for path in program_paths:
    print(f"Analizarea codului din {path}:")
    with open(path, "r") as file:
        program = file.read()
        analyze_code(program)
    print()




# Generarea șirului HTML
html = """
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        /* Stilizare pentru aspectul paginii de dashboard */

        /* ... */

    </style>
</head>
<body>
    <h1>Dashboard</h1>

    <h2>Procente de similaritate</h2>
    <table>
        <thead>
            <tr>
                <th>Programe</th>
                <th>Procent de similaritate</th>
            </tr>
        </thead>
        <tbody>
            {% for program in programs %}
            <tr>
                <td>{{ program.path }}</td>
                <td>{{ program.similarity }}%</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>

    <h2>Diferențe</h2>
    {% for program in programs %}
        <h3>{{ program.path }}</h3>
        {% if program.differences %}
            <pre>{{ program.differences | join('\n') }}</pre>
        {% else %}
            <p>Nu există diferențe între programe.</p>
        {% endif %}
    {% endfor %}

    <h2>Timp de execuție</h2>
    <h3>Cel mai bun timp de execuție: {{ sorted_programs[0][1]:.6f}} secunde</h3>
    <ul>
        {% for program, execution_time in sorted_programs %}
        {% if execution_time == sorted_programs[0][1] %}
        <li>Cale: {{ program }}, Timp: {{ execution_time:.6f }} secunde</li>
        {% endif %}
        {% endfor %}
    </ul>

    <h3>Cel mai prost timp de execuție: {{ sorted_programs[-1][1]:.6f }} secunde</h3>
    <ul>
        {% for program, execution_time in sorted_programs %}
        {% if execution_time == sorted_programs[-1][1] %}
        <li>Cale: {{ program }}, Timp: {{ execution_time:.6f }} secunde</li>
        {% endif %}
        {% endfor %}
    </ul>

    <h2>Program(e) în ordinea timpilor de execuție</h2>
    <ol>
        {% for i, (path, execution_time) in enumerate(sorted_programs) %}
        <li>Cale: {{ path }}, Timp: {{ execution_time:.6f }} secunde</li>
        {% endfor %}
    </ol>
</body>
</html>
"""

# Salvarea HTML-ului în fișier
output_file = r'C:\Users\roman\PycharmProjects\licentacuflask\templates\dashboard.html'

with open(output_file, 'w', encoding='utf-8') as file:
    file.write(html)

print("Dashboardul a fost generat cu succes în fișierul 'dashboard.html'.")
